
package figures;

public interface Shape {

    public void moveBy(int dx, int dy);

}
