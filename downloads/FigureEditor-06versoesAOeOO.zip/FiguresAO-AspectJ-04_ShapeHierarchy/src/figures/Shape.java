
package figures;

public abstract class Shape {

    public abstract void moveBy(int dx, int dy);
    
    public void setLike(int x){}

}
