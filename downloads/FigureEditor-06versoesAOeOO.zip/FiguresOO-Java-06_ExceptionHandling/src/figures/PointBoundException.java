package figures;

public class PointBoundException extends Exception{
	
	public PointBoundException(String msg){
		super(msg);
	}

}
