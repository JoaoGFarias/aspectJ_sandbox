
package figures;

public class Display {
    
    public static void update() {
    	System.out.println("Figure updated!!");
    }
}
    
