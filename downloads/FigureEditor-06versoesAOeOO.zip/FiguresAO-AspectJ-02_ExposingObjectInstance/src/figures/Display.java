
package figures;

public class Display {
    
    public static void update(Shape s) {
    	System.out.println("Figure "+s+" updated!!");
    }
}
    
