
package figures;

public class Display {
	
	//... other declarations, methods etc
    
}
    
