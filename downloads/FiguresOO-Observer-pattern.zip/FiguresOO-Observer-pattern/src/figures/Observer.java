package figures;

public interface Observer {
	public void update(Object obs);
}
